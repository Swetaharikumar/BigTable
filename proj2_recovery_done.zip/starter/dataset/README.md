movies.csv:

Cornell Movie-Dialogs Corpus  
Distributed together with:  
"Chameleons in imagined conversations: A new approach to understanding coordination of linguistic style in dialogs"  
Cristian Danescu-Niculescu-Mizil and Lillian Lee  
Proceedings of the Workshop on Cognitive Modeling and Computational Linguistics, ACL 2011.  

Downloaded from https://www.kaggle.com/Cornell-University/movie-dialog-corpus  
If you have results to report on these corpora, please send email to cristian@cs.cornell.edu or llee@cs.cornell.edu so we can add you to our list of people using this data.  
